package com.mycompany.ehks;

import java.util.ArrayList;
import java.util.List;

public class Validator {

    //  Hilfsmethoden 
    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    //  Gültigkeitsprüfung für Patienten (KBV-Plausi Prävention) 
    public static boolean isValidGeschlecht(String geschlecht) {
        return geschlecht != null
                && (geschlecht.equals("M") || geschlecht.equals("F") || geschlecht.equals("UN"));
    }

    public static boolean isValidVersichertenArt(String art) {
        return art != null
                && (art.equals("1") || art.equals("3") || art.equals("5"));
    }

    public static boolean isValidPatient(
            String name,
            String vorname,
            String geburtsdatum,
            String versichertenId,
            String strasse,
            String hausnummer,
            String plz,
            String ort,
            String versichertenArt,
            String geschlecht,
            String betriebsstaettenNr,
            String arztnummer,
            String arztname
    ) {
        // Alle Pflichtfelder checken
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        if (vorname == null || vorname.trim().isEmpty()) {
            return false;
        }
        if (geburtsdatum == null || !geburtsdatum.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return false;
        }
        try {
            java.time.LocalDate.parse(geburtsdatum);
        } catch (Exception e) {
            return false;
        }
        if (versichertenId == null || versichertenId.trim().isEmpty()) {
            return false;
        }
        if (strasse == null || strasse.trim().isEmpty()) {
            return false;
        }
        if (hausnummer == null || hausnummer.trim().isEmpty()) {
            return false;
        }
        if (plz == null || plz.trim().isEmpty()) {
            return false;
        }
        if (ort == null || ort.trim().isEmpty()) {
            return false;
        }
        if (versichertenArt == null || !isValidVersichertenArt(versichertenArt)) {
            return false;
        }
        if (geschlecht == null || !isValidGeschlecht(geschlecht)) {
            return false;
        }
        if (betriebsstaettenNr == null || betriebsstaettenNr.trim().isEmpty()) {
            return false;
        }
        if (arztnummer == null || arztnummer.trim().isEmpty()) {
            return false;
        }
        if (arztname == null || arztname.trim().isEmpty()) {
            return false;
        }

        return true;
    }

    //  Gültigkeitsprüfung für Screenings (KBV-Plausi Hautkrebs-Screening, v1.04) 
    public static boolean isValidScreening(ScreeningData screening) {
        List<String> errors = getValidationErrors(screening);
        return errors.isEmpty();
    }

    public static List<String> getValidationErrors(ScreeningData screening) {
        List<String> errors = new ArrayList<>();

        if (screening == null) {
            errors.add("Screening ist null.");
            return errors;
        }

        //  1.1 Verdachtsdiagnose
        // 1.1.1 VerdachtsdiagnoseND = Pflichtfeld, muss Ja sein
        if (!screening.isVerdachtsdiagnoseND()) {
            errors.add("1.1.1 VerdachtsdiagnoseND muss 'Ja' sein.");
        } else {
            // Zählen aller Angaben in 1.1.2–1.1.7
            int anzahlDiagnosen = 0;
            if (screening.isMalignesMelanom()) {
                anzahlDiagnosen++;
            }
            if (screening.isBasalzellkarzinom()) {
                anzahlDiagnosen++;
            }
            if (screening.isSpinozellulaeresKarzinom()) {
                anzahlDiagnosen++;
            }
            if (screening.isAndererHautkrebs()) {
                anzahlDiagnosen++;
            }
            if (screening.isSonstigerDermatologischerBefund()) {
                anzahlDiagnosen++;
            }
            if (screening.isUeberweisungAnDermatologen()) {
                anzahlDiagnosen++;
            }

            // Pflicht: Mindestens eine Angabe in 1.1.2–1.1.7
            if (anzahlDiagnosen == 0) {
                errors.add("1.1: Bei 'VerdachtsdiagnoseND = Ja' muss mindestens eine Angabe in 1.1.2–1.1.7 erfolgen.");
            }

            // KBV: "nur eine Angabe ist möglich" muss genau 1 sein
            if (anzahlDiagnosen != 1) {
                errors.add("1.1: Es darf **nur eine** Angabe in 1.1.2–1.1.7 gegeben sein (momentan: " + anzahlDiagnosen + ").");
            }

            // KBV: 1.1.7 "nur eine Angabe" wenn Ja, dann keine anderen (1.1.2–1.1.6)
            if (screening.isUeberweisungAnDermatologen()
                    && (screening.isMalignesMelanom()
                    || screening.isBasalzellkarzinom()
                    || screening.isSpinozellulaeresKarzinom()
                    || screening.isAndererHautkrebs()
                    || screening.isSonstigerDermatologischerBefund())) {
                errors.add("1.1.7: Bei 'Überweisung an Dermatologen = Ja' dürfen keine anderen Diagnosen (1.1.2–1.1.6) angegeben werden.");
            }
        }

        //  1.2 Gesundheitsuntersuchung
        if (!screening.isGesundheitsuntersuchung()) {
            errors.add("1.2 Gesundheitsuntersuchung muss 'Ja' sein.");
        }

        //  2.1 Überweisung 
        if (!screening.isUeberweisungImRahmenHKS()) {
            errors.add("2.1.1 'Patient kommt auf Überweisung im Rahmen HKS' muss 'Ja' sein.");
        }
        if (!screening.isUeberweisenderArztHatHKS()) {
            errors.add("2.1.2 'Überweisender Arzt hat HKS durchgeführt' muss 'Ja' sein.");
        }

        //  2.2 Angabe der Verdachtsdiagnose des überweisenden Arztes
        if (screening.isAngabeUeberweisenderArzt()) {
            int anzahlUeberweisend = 0;
            if (screening.isUeberweisenderArztMalignesMelanom()) {
                anzahlUeberweisend++;
            }
            if (screening.isUeberweisenderArztBasalzellkarzinom()) {
                anzahlUeberweisend++;
            }
            if (screening.isUeberweisenderArztSpinozellulaeresKarzinom()) {
                anzahlUeberweisend++;
            }
            if (screening.isUeberweisenderArztAndererHautkrebs()) {
                anzahlUeberweisend++;
            }

            if (anzahlUeberweisend == 0) {
                errors.add("2.2.2–2.2.5: Bei 'Angabe liegt vor' muss mindestens eine Verdachtsdiagnose angegeben werden.");
            } else if (anzahlUeberweisend > 1) {
                errors.add("2.2.1: Es darf **nur eine** Verdachtsdiagnose des überweisenden Arztes angegeben werden.");
            }
        } else {
            if (screening.isUeberweisenderArztMalignesMelanom()
                    || screening.isUeberweisenderArztBasalzellkarzinom()
                    || screening.isUeberweisenderArztSpinozellulaeresKarzinom()
                    || screening.isUeberweisenderArztAndererHautkrebs()) {
                errors.add("2.2.2–2.2.5: Wenn 'Angabe liegt vor' = Nein, dürfen keine Diagnosen angegeben werden.");
            }
        }

        //  2.3 Verdachtsdiagnose des Dermatologen
        if (!screening.isDermatologeVerdachtsdiagnose()) {
            errors.add("2.3.1 Verdachtsdiagnose des Dermatologen muss 'Ja' sein.");
        } else {
            int dermatologeAnzahl = 0;
            if (screening.isDermatologeMalignesMelanom()) {
                dermatologeAnzahl++;
            }
            if (screening.isDermatologeBasalzellkarzinom()) {
                dermatologeAnzahl++;
            }
            if (screening.isDermatologeSpinozellulaeresKarzinom()) {
                dermatologeAnzahl++;
            }
            if (screening.isDermatologeAndererHautkrebs()) {
                dermatologeAnzahl++;
            }
            if (screening.isDermatologeSonstigerBiopsieBefund()) {
                dermatologeAnzahl++;
            }

            if (dermatologeAnzahl == 0) {
                errors.add("2.3.2–2.3.6: Bei 'Verdachtsdiagnose' = Ja muss mindestens eine Verdachtsdiagnose angegeben werden.");
            } else if (dermatologeAnzahl > 1) {
                errors.add("2.3.1: Es darf **nur eine** Verdachtsdiagnose des Dermatologen angegeben werden.");
            }
        }

        //  2.4 Biopsie/Exzision
        if (!screening.isBiopsieOderExzision()) {
            errors.add("2.4.1 'Biopsie/Exzision' muss 'Ja' sein.");
        } else {
            int anzahlBiopsien = screening.getAnzahlBiopsien();
            if (anzahlBiopsien < 0 || anzahlBiopsien > 99) {
                errors.add("2.4.2 'Anzahl der entnommenen Biopsien' muss zwischen 0 und 99 liegen.");
            }

            // KBV: 2.4.3/2.4.4 müssen sich ausschließen
            if (screening.isAnderweitigeTherapie() && screening.isKeineWeitereTherapie()) {
                errors.add("2.4.3/2.4.4: 'anderweitige Therapie' und 'keine weitere Therapie' können nicht beide 'Ja' sein.");
            }
        }

        //  2.5 Histopathologie
        if (!screening.isBiopsieOderExzision()) {
            if (screening.isHistopathologieMalignesMelanom()
                    || screening.isHistopathologieBasalzellkarzinom()
                    || screening.isHistopathologieSpinozellulaeresKarzinom()
                    || screening.isHistopathologieAndererHautkrebs()
                    || screening.isHistopathologieAtypischerNaevus()
                    || screening.isHistopathologieJunktionalerNaevus()
                    || screening.isHistopathologieAktinischeKeratose()
                    || screening.isHistopathologieAndereVeränderung()) {
                errors.add("2.5: Keine Histopathologie-Felder erlaubt, wenn 'Biopsie/Exzision' = Nein.");
            }
        } else {
            // Zählen der 2.5.1–2.5.4-Diagnosen (Hautkrebse)
            int histopathKrebsAnzahl = 0;
            if (screening.isHistopathologieMalignesMelanom()) {
                histopathKrebsAnzahl++;
            }
            if (screening.isHistopathologieBasalzellkarzinom()) {
                histopathKrebsAnzahl++;
            }
            if (screening.isHistopathologieSpinozellulaeresKarzinom()) {
                histopathKrebsAnzahl++;
            }
            if (screening.isHistopathologieAndererHautkrebs()) {
                histopathKrebsAnzahl++;
            }

            if (histopathKrebsAnzahl == 0) {
                errors.add("2.5.1–2.5.4: Bei 'Biopsie/Exzision' muss mindestens eine Hautkrebs-Diagnose (Melanom/Basalzell/Spinozell/Anderer Hautkrebs) angegeben werden.");
            } else if (histopathKrebsAnzahl > 1) {
                errors.add("2.5.1–2.5.4: Es darf **nur eine** Hautkrebs-Diagnose angegeben werden.");
            }

            // Bedingte Pflichtfelder für Hautkrebs-Diagnosen
            if (screening.isHistopathologieMalignesMelanom()) {
                if (isBlank(screening.getMelanomKlassifikation())) {
                    errors.add("2.5.1.1 'Klassifikation (Melanom)' ist Pflicht bei Melanom.");
                }
            }

            if (screening.isHistopathologieBasalzellkarzinom()) {
                Double h = screening.getBasalzellHorizontal();
                if (h == null || h < 0.1 || h > 999.9) {
                    errors.add("2.5.2.1 'Horizontaler Tumordurchmesser (Basalzell)' muss 0.1–999.9 mm sein.");
                }
            }

            if (screening.isHistopathologieSpinozellulaeresKarzinom()) {
                if (isBlank(screening.getSpinozellulaeresKlassifikation())) {
                    errors.add("2.5.3.1 'Klassifikation (Spinozell)' ist Pflicht bei Spinozell.");
                }
            }

            // KBV: 2.5.5–2.5.8 "mindestens eine Angabe erforderlich"
            boolean hatNaevus = screening.isHistopathologieAtypischerNaevus();
            boolean hatJunktional = screening.isHistopathologieJunktionalerNaevus();
            boolean hatKeratose = screening.isHistopathologieAktinischeKeratose();
            boolean hatAndere = screening.isHistopathologieAndereVeränderung();

            if (!hatNaevus && !hatJunktional && !hatKeratose && !hatAndere) {
                errors.add("2.5.5–2.5.8: Bei 'Biopsie/Exzision' muss mindestens eine der Nävi/Keratosen angegeben werden.");
            }
        }

        //  Patient und Untersuchungsdatum 
        if (screening.getPatient() == null) {
            errors.add("Patient ist nicht gesetzt.");
        } else if (!screening.getPatient().isValid()) {
            errors.add("Patient ist nicht gültig (KBV-Prävention-Plausi fehlgeschlagen).");
        }

        if (screening.getUntersuchungsdatum() == null) {
            errors.add("Untersuchungsdatum ist nicht gesetzt.");
        }

        return errors;
    }

    // Hilfsmethoden für spezifische Wertebereiche
    public static boolean isValidAnzahlBiopsien(int anzahl) {
        return anzahl >= 0 && anzahl <= 99;
    }

    public static boolean isValidTumordurchmesser(Double durchmesser) {
        return durchmesser != null && durchmesser >= 0.1 && durchmesser <= 999.9;
    }

    public static boolean isValidMelanomKlassifikation(String klassifikation) {
        return klassifikation != null
                && (klassifikation.equals("in situ") || klassifikation.equals("invasiv"));
    }

    public static boolean isValidSpinozellulaeresKlassifikation(String klassifikation) {
        return klassifikation != null
                && (klassifikation.equals("in situ") || klassifikation.equals("invasiv"));
    }

    public static boolean isValidGrading(String grading) {
        return grading != null
                && (grading.equals("Gx") || grading.equals("G1")
                || grading.equals("G2") || grading.equals("G3") || grading.equals("G4"));
    }

    public static boolean isValidBreslow(String breslow) {
        return breslow != null
                && (breslow.equals("≤ 1 mm") || breslow.equals("1,01-2 mm")
                || breslow.equals("2,01-4 mm") || breslow.equals("> 4 mm"));
    }
}
