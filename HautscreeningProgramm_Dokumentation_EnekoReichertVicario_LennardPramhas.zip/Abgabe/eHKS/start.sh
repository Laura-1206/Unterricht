cd /home/jr/jr/Eneko/FächerverbindenderUnterricht/eHKS
mvn clean javafx:run
